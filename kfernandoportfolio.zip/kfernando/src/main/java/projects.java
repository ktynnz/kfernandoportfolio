


import jakarta.servlet.http.HttpServlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.util.*;

/**
 * Servlet implementation class projects
 */
@WebServlet("/projects")
public class projects extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public projects() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
	}

		
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String destination = "projects.jsp"; 
		RequestDispatcher requestDispatcher = request.getRequestDispatcher(destination);
		
		String title = request.getParameter("title");
		String description="", live="", git=""; 
	  
		PrintWriter out = response.getWriter();
		  
			try { 
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/kfportfolio", "root", ""); 
				Statement select = con.createStatement(); 
				ResultSet rs = select.executeQuery("SELECT * FROM project where title = '" +  title + "'");
		  
					while (rs.next()) { 
						//projectID = rs.getInt("pid"); 
						title = rs.getString("title"); 
						description = rs.getString("description");
						live = rs.getString("live");
						git = rs.getString("git");
			  
						//convert blob from db to byte in order to display in JSP
						byte[] imgData = rs.getBytes("preview");
						String encode = Base64.getEncoder().encodeToString(imgData);
						
						//passing variables to JSP 
						request.setAttribute("imgBase", encode);
						request.setAttribute("title", title); 
						request.setAttribute("description", description); 
						request.setAttribute("live", live); 
						request.setAttribute("git", git); 
		  
						requestDispatcher.forward(request, response); 		  
					}
					
		  } catch (Exception e) { 
		  out.print(e); }
	
	}
}

	
